import cgi

form = cgi.FieldStorage()
text1 = form.getfirst("email", "не задано")
text2 = form.getfirst("psw", "не задано")
text3 = form.getfirst("psw-repeat", "не задано")

print("Content-type: text/html\n")
print("""<!DOCTYPE HTML>
        <html>
        <head>
            <meta charset="utf-8">
      
            <title>Регистрация</title>
        </head>
        <body>""")


print("<p>email: {}</p>".format(text1))
print("<p>psw: {}</p>".format(text2))
print("<p>psw-repeat: {}</p>".format(text3))

print("""</body>
        </html>""")
